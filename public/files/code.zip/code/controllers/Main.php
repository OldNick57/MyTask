<?php
  class Main

  /**
  *  Create page layout with changed content
  */

 {


  public $id;

  function __construct()
  {
  // It's MVC feachure
  $this->view = new Page;
  }

  function __destruct()
  {

  }

// Home page

  public function login()
  {

  $this->view->layout('login', 'Login');

  }

  // New user registration
  public function register()
  {

  $this->view->layout('register', 'Registration form');

  }

  // Add new user and send email for confirmation
  public function add()
  {

  $this->view->layout('add', 'Registration');

  }

  // User's email confirmation
  public function confirm()
  {

  $this->view->layout('confirm', 'Confirmation');

  }

  // Check password and begin session
  public function profile()
  {

  $this->view->layout('profile', 'Profile');

  }

  // Send changed email for confirmation
  public function email()
  {

  $this->view->layout('email', 'Change email');

  }

  // User's new email confirmation
  public function change()
  {

  $this->view->layout('change', 'New email');

  }

  // Session and
  public function logout()
  {

  $this->view->layout('logout', 'Logout');

  }

   // User's list (for admin only)
  public function members()
  {

  $this->view->layout('members', 'Members');

  }

 // Session's list (for admin only)
 public function sessions()
  {

  $this->view->layout('sessions', 'Sessions');

  }

  // Failed logon's list (for admin only)
  public function failed()
  {

  $this->view->layout('failed', 'Failed logons');

  }

  // for Error 404

  public function error()
  {

  $this->view->layout('error', 'Error');

  }

}

?>