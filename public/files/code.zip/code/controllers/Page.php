<?php
  class Page

  // Create layout

{

  public $content, $title, $head;

  function __construct()
  {

  }

  function __destruct()
  {

  }

  //  Page standard layout with changed content

  public function layout($content, $head)
  {

  $title = $head;
  require_once '../pages/header.php';
  require_once '../pages/' . $content . '.php';
  require_once '../pages/footer.php';

  }


}
?>