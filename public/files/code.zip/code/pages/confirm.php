<?php

if(isset($_GET['hash'])) {
     include_once('../model/Baza.php');

    $db = new Baza;
    $inserted = $db->confirm($_GET['hash']);

   if($inserted) {   $_SESSION['confirmed'] = true;
   header("Location: /");
   exit;

  } else {

  echo '<div class="signin-form"><h3 class="form-title">Email not confirmed</h3></div>';

  }

}