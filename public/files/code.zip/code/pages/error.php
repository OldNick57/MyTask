<div class="main">

        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/error.png" alt="sing up image"></figure>
                        </div>

                          <div class="signin-form">
                        <h3 class="form-title">Page not found</h3>
                          </div>
                </div>
            </div>
        </section>

    </div>
