
<?php

 // error_reporting(E_ERROR | E_PARSE | E_NOTICE);

 include_once('../model/Baza.php');

    //Although placeholders are used, let's add filtering too.
     $username = htmlspecialchars($_REQUEST['your_name'], ENT_QUOTES);

     $db = new Baza;
     $arr = $db->login($username);


     if($arr['confirmed'] == 'N') {
     $_SESSION['repeat'] = 1;
     header("Location: /");
     exit;

    }

     if(count($arr) < 1) {
     $_SESSION['nouser'] = 1;

     header("Location: /");
     exit;

    }


    if(password_verify($_REQUEST['your_pass'], $arr['password'])) {

    $_SESSION['uid'] = $arr['id'];
    $_SESSION['username'] = $arr['username'];

    $upd = $db->session($_SESSION['uid']);

    } else {

    $_SESSION['nopasswd'] = 1;
    $db->failed();

    header("Location: /");
    exit;
    }


?>

<div class="main">
       <!-- Profile -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Profile</h2>
                        <form method="POST" class="register-form" id="register-form" action="main/email">
                            <div class="form-group">
                           <h4>Hello,&nbsp; <?php echo $_SESSION['username'] ?><h4><br />
                           <?php if($_SESSION['username'] == 'admin') {

print('Explore:&nbsp;&nbsp;<a href="members">Members</a>&nbsp;&nbsp;&nbsp;<a href="sessions">Sessions</a>&nbsp;&nbsp;&nbsp;<a href="failed">Failed</a>');

}

?>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="You can change your email"/>
                            </div>
                            <div class="form-group">
                                  <div class="form-group form-button">
                                <input type="submit" name="save" id="save" class="form-submit" value="Change"/>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/kabinet.jpg" alt="sing up image"></figure>
                        <a href="main/logout" class="signup-image-link">Logout</a>
                    </div>
                </div>
            </div>
        </section>

    </div>
