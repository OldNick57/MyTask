	<div id="footer">
<div id = "copy">&copy;&nbsp;&nbsp;Nikolay Goodanetz,&nbsp; <?php echo date("Y"); ?>
 </div>
	</div>

</div><!-- #super_wrapper -->

</body></html>